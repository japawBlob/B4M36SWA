package com.progressivecoder.es.eventsourcingaxonspringboot.aggregates;

public enum Status {
    CREATED, ACTIVATED, HOLD
}
